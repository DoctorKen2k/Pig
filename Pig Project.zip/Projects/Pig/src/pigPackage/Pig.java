package pigPackage;

import java.util.*;

public class Pig {
	
	public static void main (String [] args)
    {
        Scanner input = new Scanner (System.in);  //Declaration of scanner added for players' input.
    
        final int ACE = 1;  //Appropriate variables.
        int die1, die2, dice;
        int playerOneSum = 0; 
        int playerTwoSum = 0; 
        int rollAgain = 0;
        int playMore = 0;
        int roundCounter = 1;
    
        do  //Loop for playing the game again after it is over.
        {
            System.out.println("\nRound " + roundCounter + " for Player One.");  //Counts the current round for player one.
            do  //Player One's Loop
            { 
                die1 = (int)(6 * Math.random() + (1));  //Randomly picks numbers 1-6.
                die2 = (int)(6 * Math.random() + (1));
                dice = die1 + die2;  //Combines those randomly chosen numbers.
        
                if (die1 == ACE && die2 == ACE)  //Condition for two random chosen 1(s).
                {
                    dice = 25;
                    System.out.println("\nPlayer One's Roll:");
                    System.out.println("Die 1: " + die1);
                    System.out.println("Die 2: " + die2);
                    System.out.println("Player One's Score: " + dice);
                    playerOneSum = playerOneSum + dice;
                    System.out.println("The total score for Player One: " + playerOneSum + ".");
                    if (playerOneSum > 49)
                    {
                        rollAgain = 2;
                    }
                    else
                    {
                        System.out.print("\nDo you want to roll again?  Press 1 for yes and 2 for no. ");
                        rollAgain = input.nextInt();
                    }
                }
                else if (die1 == ACE || die2 == ACE)  //Condition if an Ace is only rolled once.
                {
                    dice = 0;
                    playerOneSum = 0;
                    System.out.println("\nPlayer One's Roll:");
                    System.out.println("Die 1: " + die1);
                    System.out.println("Die 2: " + die2);
                    System.out.println("You rolled an Ace or a 1.  Your score is " + dice + ".");
                    rollAgain = 2;
                }
                else if (die1 == die2)  //Condition if both random numbers share the same value.
                {
                    dice = (die1 + die2) * 2;
                    System.out.println("\nPlayer One's Roll:");
                    System.out.println("Die 1: " + die1);
                    System.out.println("Die 2: " + die2);
                    System.out.println("Player One's Score: " + dice);
                    playerOneSum = playerOneSum + dice;
                    System.out.println("The total score for Player One: " + playerOneSum + ".");
                    if (playerOneSum > 49)
                    {
                        rollAgain = 2;
                    }
                    else                
                    {       
                        System.out.print("\nDo you want to roll again?  Press 1 for yes and 2 for no. ");
                        rollAgain = input.nextInt();
                    }
                }
                else
                {       
                    System.out.println("\nPlayer One's Roll:");
                    System.out.println("Die 1: " + die1);
                    System.out.println("Die 2: " + die2);
                    System.out.println("Player One's Score: " + dice);
                    playerOneSum = playerOneSum + dice;
                    System.out.println("The total score for Player One: " + playerOneSum + ".");
                    if (playerOneSum > 49)  //Condition automatically ends player one's turn if his/her score reaches over 50.
                    {
                        rollAgain = 2;
                    }
                    else
                    {
                        System.out.print("\nDo you want to roll again?  Press 1 for yes and 2 for no. ");
                        rollAgain = input.nextInt();
                    }
                }
            
            } while (rollAgain == 1);
            
            System.out.println("\n********************************************************************************************************************************************");
            System.out.println("");
            
            System.out.println("Round " + roundCounter + " for Player Two.");  //Counts current round for player two.
            do  //Player Two's Loop
            {
                die1 = (int)(6 * Math.random() + (1));  //Randomly chooses number 1-6.
                die2 = (int)(6 * Math.random() + (1));
                dice = die1 + die2;  //Adds for randomly chosen numbers together.
        
                if (die1 == ACE && die2 == ACE)  //Condition for two random chosen 1(s).
                {
                    dice = 25;
                    System.out.println("\nPlayer Two's Roll:");
                    System.out.println("Die 1: " + die1);
                    System.out.println("Die 2: " + die2);
                    System.out.println("Player Two's Score: " + dice);
                    playerTwoSum = playerTwoSum + dice;
                    System.out.println("The total score for Player One: " + playerTwoSum + ".");
                    if (playerTwoSum > 49)
                    {
                        rollAgain = 2;
                    }
                    else
                    {
                        System.out.print("\nDo you want to roll again?  Press 1 for yes and 2 for no. ");
                        rollAgain = input.nextInt();
                    }
                }
                else if (die1 == ACE || die2 == ACE)  //Condition if an Ace is only rolled once.
                {
                    dice = 0;
                    playerTwoSum = 0;
                    System.out.println("\nPlayer Two's Roll:");
                    System.out.println("Die 1: " + die1);
                    System.out.println("Die 2: " + die2);
                    System.out.println("You rolled an Ace or a 1.  Your score is " + dice + ".");
                    rollAgain = 2;
                }
                else if (die1 == die2)  //Condition if both random numbers share the same value.
                {
                    dice = (die1 + die2) * 2;
                    System.out.println("\nPlayer Two's Roll:");
                    System.out.println("Die 1: " + die1);
                    System.out.println("Die 2: " + die2);
                    System.out.println("Player Two's Score: " + dice);
                    playerTwoSum = playerTwoSum + dice;
                    System.out.println("The total score for Player Two: " + playerTwoSum + ".");
                    if (playerTwoSum > 49)
                    {
                        rollAgain = 2;
                    }
                    else                
                    {       
                        System.out.print("\nDo you want to roll again?  Press 1 for yes and 2 for no. ");
                        rollAgain = input.nextInt();
                    }
                }
                else
                {       
                    System.out.println("\nPlayer Two's Roll:");
                    System.out.println("Die 1: " + die1);
                    System.out.println("Die 2: " + die2);
                    System.out.println("Player Two's Score: " + dice);
                    playerTwoSum = playerTwoSum + dice;
                    System.out.println("The total score for Player Two: " + playerTwoSum + ".");  

                    if (playerOneSum > 49 && playerTwoSum > 49)  //Condition to escape loop if player one and two scores are over 50.
                    {
                        rollAgain = 2;
                    }
                    else
                    {
                        System.out.print("\nLet's see who won! ");
                    }
                }
            
            } while (rollAgain == 1); 
            
            if (playerOneSum > 49 && playerOneSum > playerTwoSum)  //Condition that checks for the winner.
            {
                System.out.println("\nPlayer One wins the game during Round " + roundCounter + "!");
                System.out.print("\nDo you want to play the game again?  Press 1 for yes and 2 for no. ");
                playMore = input.nextInt();
                playerOneSum = 0;
                playerTwoSum = 0;
                roundCounter = 0;
            }
            else if (playerTwoSum > 49 && playerTwoSum > playerOneSum)
            {
                System.out.println("\nPlayer Two wins the game during Round " + roundCounter + "!");
                System.out.print("\nDo you want to play the game again?  Press 1 for yes and 2 for no. ");
                playMore = input.nextInt();
                playerOneSum = 0;
                playerTwoSum = 0;
                roundCounter = 0;
            }
            else
            {
                playMore = 1;  //Repeat game if it is played again.
            }
           
         roundCounter++;
         System.out.println("\n********************************************************************************************************************************************");
        }while (playMore == 1);
    }
}


